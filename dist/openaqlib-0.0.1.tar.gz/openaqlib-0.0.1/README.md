# OpenAQ Package
> This will import a few basic api functions for your use. 
<sub>You can see them using dir(openaq) and read the doc strings with help(*function name*)
